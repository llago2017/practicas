import XCTest

import CollectionsTests

var tests = [XCTestCaseEntry]()
tests += CollectionsTests.allTests()
XCTMain(tests)
