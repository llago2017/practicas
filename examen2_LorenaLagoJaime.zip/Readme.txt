El ejercicio 3 se ejecuta con "swift run" la función de prueba está incluida en el main ya que no me permitía incorparla en otro módulo por problemas de protección aun estando todo con "public".

-- Lorena Lago Jaime
